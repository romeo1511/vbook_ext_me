load('config.js');

function execute(url, page) {
    let response = fetch(BASE_URL + "/api/manga");
    if (response.ok) {
        let mangas = response.json();
        let novelList = mangas.map(m => ({
            name: m.title,
            link: BASE_URL + "/manga/" + m.id,
            cover: m.cover_path ? (BASE_URL + "/api/cover/" + m.id) : "",
            description: m.chapter_count + " chương",
            host: BASE_URL
        }));
        return Response.success(novelList, null);
    }
    return null;
}