load('config.js');

function execute(url) {
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);

    // Try API endpoint first if URL contains manga ID: /manga/<id>
    let match = url.match(/\/manga\/(\d+)/);
    if (match) {
        let mangaId = match[1];
        let apiResp = fetch(BASE_URL + "/api/manga/" + mangaId + "/chapters");
        if (apiResp.ok) {
            let chapters = apiResp.json();
            let list = chapters.map(c => ({
                name: c.title,
                url: BASE_URL + "/manga/" + mangaId + "/chapter/" + c.id,
                host: BASE_URL
            }));
            return Response.success(list);
        }
    }

    // Fallback: HTML Selector Parsing
    let response = fetch(url);
    if (response.ok) {
        let doc = response.html();
        let list = [];
        doc.select(".chapter-card-grid, .chapter-item").forEach(e => {
            let link = e.attr("href");
            let title = e.select(".chapter-card-title, .chapter-item-title").text();
            if (link) {
                list.push({
                    name: title || "Chương",
                    url: link.startsWith("http") ? link : (BASE_URL + link),
                    host: BASE_URL
                });
            }
        });
        return Response.success(list);
    }
    return null;
}