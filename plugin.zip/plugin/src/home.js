load('config.js');
function execute() {
    return Response.success([
        { title: "Mới cập nhật", input: BASE_URL + "/api/manga", script: "gen.js" },
        { title: "Tất cả truyện", input: BASE_URL + "/api/manga", script: "gen.js" }
    ]);
}
