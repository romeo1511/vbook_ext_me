load('config.js');

function execute(url, page) {
    let response = fetch(url);
    if (response && response.ok) {
        let contentType = response.headers ? (response.headers["content-type"] || "") : "";
        if (contentType.includes("application/json") || url.includes("/api/")) {
            let mangas = response.json();
            let novelList = mangas.map(m => ({
                name: m.title,
                link: BASE_URL + "/manga/" + m.id,
                cover: m.cover_path ? (BASE_URL + "/api/cover/" + m.id) : "",
                description: m.chapter_count + " chương",
                type: "comic",
                host: BASE_URL
            }));
            return Response.success(novelList, null);
        } else {
            let doc = response.html();
            let novelList = [];
            doc.select(".manga-card").forEach(e => {
                let link = e.attr("href");
                let title = e.select(".manga-card-title").text();
                let cover = e.select(".manga-card-cover img").attr("src");
                let chapterText = e.select(".manga-card-badge").text();
                novelList.push({
                    name: title,
                    link: link.startsWith("http") ? link : (BASE_URL + link),
                    cover: cover ? (cover.startsWith("http") ? cover : (BASE_URL + cover)) : "",
                    description: chapterText,
                    type: "comic",
                    host: BASE_URL
                });
            });
            return Response.success(novelList, null);
        }
    }
    return null;
}