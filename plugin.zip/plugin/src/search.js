load('config.js');

function execute(key, page) {
    let response = fetch(BASE_URL + "/api/manga?q=" + encodeURIComponent(key));
    if (response.ok) {
        let mangas = response.json();
        let list = mangas.map(m => ({
            name: m.title,
            link: BASE_URL + "/manga/" + m.id,
            cover: m.cover_path ? (BASE_URL + "/api/cover/" + m.id) : "",
            description: m.chapter_count + " chương",
            host: BASE_URL
        }));
        return Response.success(list, null);
    }
    return null;
}
