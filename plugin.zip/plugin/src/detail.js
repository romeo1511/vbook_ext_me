load('config.js');

function execute(url) {
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);

    let response = fetch(url);
    if (response.ok) {
        let doc = response.html();
        let name = doc.select(".detail-title").text();
        let cover = doc.select(".detail-cover img").attr("src");
        if (cover && !cover.startsWith("http")) {
            cover = BASE_URL + cover;
        }
        let description = doc.select(".detail-info p").text() || "MangaShelf Local Library";

        return Response.success({
            name: name,
            cover: cover || "",
            author: "Local Library",
            description: description,
            host: BASE_URL
        });
    }
    return null;
}