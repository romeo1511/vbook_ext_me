load('config.js');

function execute(url) {
    if (!url.startsWith("http")) {
        url = BASE_URL + (url.startsWith("/") ? "" : "/") + url;
    } else {
        url = url.replace(/^https?:\/\/[^\/]+/, BASE_URL);
    }

    let response = fetch(url);
    if (response && response.ok) {
        let doc = response.html();
        let name = doc.select(".detail-title").text();
        let cover = doc.select(".detail-cover img").attr("src");
        if (cover && !cover.startsWith("http")) {
            cover = BASE_URL + cover;
        }
        let description = doc.select(".detail-info p").text() || "MangaShelf Local Library";

        return Response.success({
            name: name,
            cover: cover || "",
            author: "Local Library",
            description: description,
            type: "comic",
            host: BASE_URL
        });
    }
    return null;
}