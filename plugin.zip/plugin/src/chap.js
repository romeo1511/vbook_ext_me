load('config.js');

function execute(url) {
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);

    // Extract chapter ID from URL if formatted like /manga/1/chapter/5
    let match = url.match(/\/chapter\/(\d+)/);
    let chapterId = match ? match[1] : null;

    let response = fetch(url);
    if (response.ok) {
        let doc = response.html();
        let readerContent = doc.select("#reader-content");
        let totalPages = parseInt(readerContent.attr("data-total-pages") || "0", 10);
        if (!chapterId) {
            chapterId = readerContent.attr("data-chapter-id");
        }

        let images = [];
        if (chapterId && totalPages > 0) {
            for (let i = 0; i < totalPages; i++) {
                images.push(BASE_URL + "/api/page/" + chapterId + "/" + i);
            }
            return Response.success(images);
        }

        // Fallback: parse <img> elements directly if present
        doc.select("#reader-content img").forEach(e => {
            let src = e.attr("src") || e.attr("data-src");
            if (src) {
                images.push(src.startsWith("http") ? src : (BASE_URL + src));
            }
        });
        if (images.length > 0) {
            return Response.success(images);
        }
    }
    return Response.error("Không thể tải trang của chương này.");
}