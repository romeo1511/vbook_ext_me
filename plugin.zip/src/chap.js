load('config.js');

function execute(url) {
    if (!url.startsWith("http")) {
        url = BASE_URL + (url.startsWith("/") ? "" : "/") + url;
    } else {
        url = url.replace(/^https?:\/\/[^\/]+/, BASE_URL);
    }

    let response = fetch(url);
    if (response && response.ok) {
        let doc = response.html();
        let images = [];

        // 1. Direct HTML Image Selector extraction (Standard for all manga sites)
        doc.select("img.manga-page, .reader-image-wrap img, #reader-content img").forEach(e => {
            let src = e.attr("src") || e.attr("data-src") || e.attr("data-original");
            if (src) {
                if (!src.startsWith("http")) {
                    src = BASE_URL + (src.startsWith("/") ? "" : "/") + src;
                }
                images.push(src);
            }
        });

        if (images.length > 0) {
            return Response.success(images);
        }

        // 2. Backup API & Attribute lookup
        let chapMatch = url.match(/\/chapter\/(\d+)/);
        let chapterId = chapMatch ? chapMatch[1] : null;
        let readerContent = doc.select("#reader-content");
        let totalPages = parseInt(readerContent.attr("data-total-pages") || "0", 10);

        if (chapterId && totalPages > 0) {
            for (let i = 0; i < totalPages; i++) {
                images.push(BASE_URL + "/api/page/" + chapterId + "/" + i);
            }
            return Response.success(images);
        }
    }
    return Response.error("Không thể tải hình ảnh của tập truyện này.");
}