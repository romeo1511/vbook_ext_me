load('config.js');

function execute() {
    return Response.success([
        { title: "Tất cả truyện", input: BASE_URL + "/api/manga", script: "gen.js" }
    ]);
}